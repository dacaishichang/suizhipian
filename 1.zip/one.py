import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
import os
import pandas as pd
from sklearn.cluster import KMeans
import cv2
import random


def Getdir(dirname):
    files=os.listdir(dirname)
    file_new=[]
    for i in files:
        i=dirname+'\\'+i
        file_new.append(i)
    return file_new


def Imagedata(filemane):
    datas=[]
    for i in filemane:
        im = Image.open(i)
        (width,height) = im.size
        im = im.convert("L")
        data = im.getdata()
        data = np.array(data,dtype=float)/255.0
        new_data = np.reshape(data,(height,width))
        datas.append(new_data)
        im.close()
    return datas
    
def Dictation(x):
    dic=[]
    for i,j in enumerate(x):
        a={'id':i,'pic':j}
        dic.append(a)
    return dic


def Uper(b,length=1):
    up=[]
    for i in b:
        a=i['pic'][:length]
        a=a.reshape(-1)
        aa={'id':i['id'],'pic':a}
        up.append(aa)
    return up
        
def Downer(b,length=1):
    down=[]
    for i in b:
        a=i['pic'][-length:]
        a=a.reshape(-1)
        aa={'id':i['id'],'pic':a}
        down.append(aa)
    return down
    
def Lefter(b,length=1):
    left=[]
    for i in b:
        a=i['pic'][:,:length]
        a=a.reshape(-1)
        aa={'id':i['id'],'pic':a}
        left.append(aa)
    return left

def Righter(b,length=1):
    right=[]
    for i in b:
        a=i['pic'][:,-length:]
        a=a.reshape(-1)
        aa={'id':i['id'],'pic':a}
        right.append(aa)
    return right
#计算左右距离

def Compute(one, another):#只适合左右的
    diff=[]
    one0=[i['id'] for i in one]
    another0=[i['id'] for i in another]
    for i in one:
        cha00=[]
        for j in another:
            if i['id']==j['id']:
                pass
            else:
                cha=sum(abs(i['pic']-j['pic']))
                cha1={'sum':cha,'right':i['id'],'left':j['id']}
                cha00.append(cha1)
#        print(len(cha00))
        mini=1e10
        minione=1e10
        minianother=1e10
        for i,j in enumerate(cha00):
            if j['sum']<mini and j['left'] in another0 and j['right'] in one0:
                mini=j['sum']
                minione=j['right']
                minianother=j['left']
        if minione!=1e10 and minianother!=1e10:
            one0.remove(minione)
            another0.remove(minianother)
            cha02={'sum':mini,'right':minione,'left':minianother}
            diff.append(cha02)
    return diff


def Bianyuan(data):#侧边缘
    sums=[]
    for i in data:
        y=i['pic'].mean()
        cha=abs(y-1)
        cha1={'cha':cha,'id':i['id']}
        sums.append(cha1)
    idc=[]
    for j in sums:
        if j['cha']==0:
            idc.append(j['id'])
    return idc

def Paixu_left(px,numlist):
    nextt=numlist[0]
    pai=[]
    for i in px:
        if i['left']==nextt:
            pai.append(nextt)
            nextt=i['right']
            break
    number=0
    while len(set(pai))==len(pai) and number<200:
        number=number+1
        for i in px:
            if i['left']==nextt:
                pai.append(nextt)
                nextt=i['right']
                break
    pai.pop()
    return pai
    
def Paixu_right(px,numlist):
    nextt=numlist[0]
    pai=[]
    for i in px:
        if i['right']==nextt:
            pai.append(nextt)
            nextt=i['left']
            break
    number=0
    while len(set(pai))==len(pai):
        number=number+1
        for i in px:
            if i['right']==nextt:
                pai.append(nextt)
                nextt=i['left']
                break
    pai.pop()
    pai.reverse()
    return pai

    
def Be_in(sth,num):#选出是选中的数据
    aa=[]
    for i in sth:
        flag=0
        for j in num:
            if i['id']==j:
                flag=1
                break
        if flag==1:
            aa.append({'pic':i['pic'],'id':i['id']})
    return aa
def Be_not(sth,num):#选出不是选中的数据
    aa=[]
    for i in sth:
       flag=1
       for j in num:
           if i['id']==j:
               flag=0
               break
       if flag==1:
           aa.append({'pic':i['pic'],'id':i['id']})
    return aa
    

    
    
def Separate_to_list(x):
    idc=[]
    data=[]
    for i in x:
        idc.append(i['id'])
        data.append(i['pic'])
        
    return idc,data
    
    
def Merge_to_dict(bian,idc):
    aa=[]
    for i,j in zip(bian,idc):
        aa.append({'id':j,'lei':i})
    return aa
    
def One_dimension(data):
    aa=[]
    for i in data:
        a=np.mean(i['pic'],axis=1)
#        a[a!=1]=0
        aa.append({'id':i['id'],'pic':a})
    return aa
#k means
def K_mean(data):
    dat=[]
    idc=[]
    for i in data:
        dat.append(i['pic'])
        idc.append(i['id'])
    km=KMeans(n_clusters=11,max_iter=5000,tol=0.0001)
    km.fit(dat)
    aa=km.predict(dat)
    bb=pd.DataFrame()
    bb['id']=idc
    bb['lei']=aa
    print(bb['lei'].value_counts())
    return bb,km
    
    
def Visual_shu(data,num):
    aa=[]
    for i in num:
        for j in data:
            if j['id']==i:
                aa.append(j['pic'])
                break
    bb=np.concatenate(aa,axis=0)
    bb=bb*255
#    new_im = Image.fromarray(bb.astype(np.uint8))
#    new_im.show()
    return bb
    
def Visual_heng(data,num):
    aa=[]
    for i in num:
        for j in data:
            if j['id']==i:
                aa.append(j['pic'])
                break
    bb=np.concatenate(aa,axis=1)
    bb=bb*255
#    new_im = Image.fromarray(bb.astype(np.uint8))
#    new_im.show()
    return bb
def Save_picture_pai(data,num,path):
    new_im = Image.fromarray(data.astype(np.uint8))
    new_im.show()
    new_im.save(path+'\\'+'result.bmp')
    ccc=pd.Series(num)
    ccc.to_csv(path+'\\result.csv')
    
def Blur(data,dim):
    pic0=data['pic']
    pic1=cv2.blur(pic0,(dim,dim))
#    cv2.imshow('001',pic1)
#    cv2.waitKey(0)
    pic2={'pic':pic1,'id':data['id']}
    return pic2
    
def Fenlei(data,idc,path,num):
    dat=[]
    for i in idc:
        for j in data:
            if i==j['id']:
                dat.append(j)
                break
    for i in dat:
        new_im = Image.fromarray((i['pic']*255).astype(np.uint8))
        new_im.save(path+'\\'+str(num)+'\\'+str(i['id'])+'.bmp')
    print('OK')




save_path=r'C:\Users\Administrator\Desktop\C碎纸片\碎1题解'
read_path=r'C:\Users\Administrator\Desktop\C碎纸片\附件1'
a=Getdir(read_path)
b=Imagedata(a)
b_dic=Dictation(b)

ri=Righter(b_dic,4)
le=Lefter(b_dic,4)

bian_le=Bianyuan(le)
bian_ri=Bianyuan(ri)

ri=Righter(b_dic,1)
le=Lefter(b_dic,1)

com=Compute(le,ri)
pai=Paixu_left(com,bian_le)


da=Visual_heng(b_dic,pai)

Save_picture_pai(da,num=pai,path=save_path)